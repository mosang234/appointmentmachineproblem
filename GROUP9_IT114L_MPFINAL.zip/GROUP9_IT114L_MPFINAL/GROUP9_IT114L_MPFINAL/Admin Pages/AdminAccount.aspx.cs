﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace GROUP9_IT114L_MPFINAL.Admin_Pages
{

    public partial class AdminAccount : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack) 
            {
                OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
                Server.MapPath("~/App_Data/MPIT114L.mdb"));
                con.Open();

                string email = Session["AdminEmail"].ToString();
                string check = "SELECT * FROM Admin WHERE AdminEmail='" + email + "';";
                OleDbCommand cmd = new OleDbCommand(check, con);
                OleDbDataReader read = cmd.ExecuteReader();
                read.Read();

                Admin_name.Text = read["AdminName"].ToString();
                Admin_telephone.Text = read["AdminTelephone"].ToString();
                Admin_address.Text = read["AdminAddress"].ToString();
                Admin_role.Text = read["AdminRole"].ToString();
                Admin_email.Text = read["AdminEmail"].ToString();

                con.Close();
            }

            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void TextBox_id_admin_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button_add_Click(object sender, EventArgs e)
        {
           
        }

        protected void Admin_telephone_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button_Update_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
                Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string email = Session["AdminEmail"].ToString();
            string get_adminid = "SELECT ID FROM Admin WHERE AdminEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_adminid, con);
            string query_id = get_id.ExecuteScalar().ToString();

            OleDbCommand conn = new OleDbCommand("UPDATE Admin set AdminName='" + Admin_name.Text + "', AdminTelephone='" + Admin_telephone.Text + "', AdminRole='" + Admin_role.Text + "', AdminAddress='" + Admin_address.Text + "' WHERE ID = " + query_id + ";", con);
            int r = conn.ExecuteNonQuery();

            if (r > 0)
            {
                Response.Write("<script>alert('Administrator Details Updated')</script>");
            }
            else
            {
                Response.Write("<script>alert('The Information was  NOT updated! Try Again!')</script>");
            }

            con.Close();
        }

        protected void Button_Clear_Click(object sender, EventArgs e)
        {
            Admin_name.Text = "";
            Admin_telephone.Text = "";
            Admin_address.Text = "";
            Admin_role.Text = "";
        }
    }
}