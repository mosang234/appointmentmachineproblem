﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace GROUP9_IT114L_MPFINAL.Admin_Pages
{
    public partial class AdminReports23 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" +
               Server.MapPath("~/App_Data/MPIT114L.mdb");

            OleDbConnection connection = new OleDbConnection(connectionString);

            string query = "SELECT * FROM Appointment WHERE status_appoint = 'Cancelled by Patient'";
            OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);

            DataSet dataset = new DataSet();
            adapter.Fill(dataset);

            GridView3.DataSource = dataset;
            GridView3.DataBind();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}