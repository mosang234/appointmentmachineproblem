﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace GROUP9_IT114L_MPFINAL.Admin_Pages
{
    public partial class Reports : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                Populate();

                Populate4();

            }

            

        }


        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string checkquery2 = "SELECT DoctorService,DoctorName FROM Appointment WHERE SelectedDate='" + Calendar1.SelectedDate.ToShortDateString() + "' AND status_appoint NOT IN ('Cancelled by Patient', 'Rejected', 'Pending');"; ;
            string checkquery = "SELECT * FROM Appointment WHERE SelectedDate='" + Calendar1.SelectedDate.ToShortDateString() + "' AND status_appoint NOT IN ('Cancelled by Patient', 'Rejected', 'Pending');"; ;
            OleDbCommand cmd = new OleDbCommand(checkquery, con);
            OleDbCommand cmd2 = new OleDbCommand(checkquery2, con);
            OleDbDataReader reader = cmd.ExecuteReader();
            OleDbDataReader reader2 = cmd2.ExecuteReader();

            if (reader.HasRows)
            {
                string query2 = "SELECT DoctorService,DoctorName FROM Appointment WHERE SelectedDate='" + Calendar1.SelectedDate.ToShortDateString() + "' AND status_appoint NOT IN ('Cancelled by Patient', 'Rejected', 'Pending');";
                // string query = "SELECT * FROM Appointment WHERE SelectedDate='" + Calendar1.SelectedDate.ToShortDateString() + "' AND status_appoint NOT IN ('Cancelled by Patient', 'Rejected', 'Pending');"; 
                OleDbDataAdapter ba = new OleDbDataAdapter(query2, con);
                //  OleDbDataAdapter da = new OleDbDataAdapter(query, con);

                //  DataTable dt = new DataTable();
                DataTable pt = new DataTable();
                // da.Fill(dt);
                ba.Fill(pt);
                // Label2.Text = Convert.ToString(dt.Rows.Count);
                GridView4.DataSource = pt;
                // GridViewspec.DataSource = dt;
                GridView4.DataBind();
                //GridViewspec.DataBind();

            }
            else
            {
                DataTable op = new DataTable();
                // GridViewspec.DataSource = op;
                GridView4.DataSource = op;
                Label2.Text = Convert.ToString(op.Rows.Count);
                GridView4.DataBind();
                // GridViewspec.DataBind();
            }

            if (reader2.HasRows)
            {
                string query = "SELECT * FROM Appointment WHERE SelectedDate='" + Calendar1.SelectedDate.ToShortDateString() + "' AND status_appoint NOT IN ('Cancelled by Patient', 'Rejected', 'Pending');";
                OleDbDataAdapter da = new OleDbDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                GridViewspec.DataSource = dt;
                GridViewspec.DataBind();
                Label2.Text = Convert.ToString(dt.Rows.Count);
            }
            else
            {
                DataTable op = new DataTable();
                GridViewspec.DataSource = op;
                Label2.Text = Convert.ToString(op.Rows.Count);

                GridViewspec.DataBind();

            }
            con.Close();
        }

        protected void GridViewspec_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        void Populate()
        {

            OleDbConnection con = new OleDbConnection("Provider =  Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string query = "SELECT * FROM Appointment WHERE SelectedDate='" + Calendar1.SelectedDate.ToShortDateString() + "' AND status_appoint NOT IN ('Cancelled by Patient', 'Rejected', 'Pending');"; ;
            OleDbDataAdapter da = new OleDbDataAdapter(query, con);
            DataTable rd = new DataTable();
            da.Fill(rd);
            GridViewspec.DataSource = rd;
            GridViewspec.DataBind();
        }

        void Populate4()
        {

            OleDbConnection con = new OleDbConnection("Provider =  Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string query = "SELECT DoctorService,DoctorName FROM Appointment WHERE SelectedDate='" + Calendar1.SelectedDate.ToShortDateString() + "' AND status_appoint NOT IN ('Cancelled by Patient', 'Rejected', 'Pending');";
            OleDbDataAdapter da = new OleDbDataAdapter(query, con);
            DataTable rd = new DataTable();
            da.Fill(rd);
            GridView4.DataSource = rd;
            GridView4.DataBind();
        }



        protected void GridView4_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[0].Text = "Doctor Service";
                e.Row.Cells[1].Text = "Doctor Name";

            }
        }





        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[0].Text = "Patient Name";

            }
        }

        protected void GridView4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
