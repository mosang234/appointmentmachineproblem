﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


namespace GROUP9_IT114L_MPFINAL.Master_Pages
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Populate2();
            Populate3();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" +
                Server.MapPath("~/App_Data/MPIT114L.mdb");
            OleDbConnection connection = new OleDbConnection(connectionString);
            connection.Open();
            string query2 = "Select * from Appointment where DoctorID=" + DropDownList1.SelectedValue;
            OleDbCommand cmd = new OleDbCommand(query2, connection);
            OleDbDataReader reader = cmd.ExecuteReader();


            if (reader.HasRows)
            {
                string query = "SELECT PatientName " +
                "FROM Appointment " +
                "WHERE DoctorID=" + DropDownList1.SelectedValue +
                " Group by PatientName ";

                OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);

                DataTable datatable = new DataTable();
                adapter.Fill(datatable);

                GridView1.DataSource = datatable;
                GridView1.DataBind();
            }
            else
            {
                DataTable op = new DataTable();
                GridView1.DataSource = op;
                GridView1.DataBind();

            }
            connection.Close();
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" +
               Server.MapPath("~/App_Data/MPIT114L.mdb");
            OleDbConnection connection = new OleDbConnection(connectionString);
            connection.Open();
            string query2 = "SELECT * FROM Appointment WHERE DoctorID =" + DropDownList2.SelectedValue + " AND status_appoint = 'Approved'";
            OleDbCommand cmd = new OleDbCommand(query2, connection);
            OleDbDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                string query = "SELECT DoctorService " +
                "FROM Appointment " +
                "WHERE DoctorID=" + DropDownList2.SelectedValue +
                " AND status_appoint='Approved'" +
                " Group by DoctorService ";

                OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);

                DataTable datatable = new DataTable();
                adapter.Fill(datatable);
                Label5.Text = Convert.ToString(datatable.Rows.Count);

                GridView2.DataSource = datatable;
                GridView2.DataBind();
            }
            else
            {
                DataTable op = new DataTable();
                GridView1.DataSource = op;
                Label5.Text = Convert.ToString(op.Rows.Count);
                GridView2.DataBind();

            }
            connection.Close();
        }
        void Populate2()
        {

            OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            string com = "SELECT * FROM Doctor WHERE Status='Active'";
            OleDbDataAdapter adapt = new OleDbDataAdapter(com, con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            DropDownList1.DataSource = dt;
            DropDownList1.DataTextField = "DoctorName";
            DropDownList1.DataValueField = "ID";
            DropDownList1.DataBind();


            con.Close();
            DropDownList1.Items.Insert(0, "-- SELECT DOCTOR --");
        }
        void Populate3()
        {

            OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            string com = "SELECT * FROM Doctor WHERE Status='Active'";
            OleDbDataAdapter adapt = new OleDbDataAdapter(com, con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            DropDownList2.DataSource = dt;
            DropDownList2.DataTextField = "DoctorName";
            DropDownList2.DataValueField = "ID";
            DropDownList2.DataBind();


            con.Close();
            DropDownList2.Items.Insert(0, "-- SELECT DOCTOR --");
        }
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[0].Text = "Patient Name";

            }
        }
    }
}