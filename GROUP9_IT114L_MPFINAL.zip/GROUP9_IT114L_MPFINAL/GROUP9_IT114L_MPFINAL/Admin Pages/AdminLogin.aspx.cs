﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GROUP9_IT114L_MPFINAL.Admin_Pages
{
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            //FINAL
        }

        protected void Button_login_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string check = "SELECT * FROM Admin WHERE AdminEmail='" + Login_name.Text + "';";
            OleDbCommand cmd = new OleDbCommand(check, con);
            OleDbDataReader read = cmd.ExecuteReader();
            if (read.HasRows)
            {
                read.Read();
                if (read["AdminPassword"].ToString() != Login_password.Text) 
                {
                    Response.Write("<script>alert('Wrong Password')</script>");

                }
                else
                {
                    Session["AdminEmail"] = Login_name.Text;
                    Response.Redirect("AdminAccount.aspx");

                }
            }
            else
            {
                Response.Write("<script>alert('Email is incorrect or does not exist')</script>");
            }
        }
    }
}