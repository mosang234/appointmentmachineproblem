﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GROUP9_IT114L_MPFINAL.Admin_Pages
{
    public partial class AdminCreate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (!this.IsPostBack)
            {
                doctorsched();
                Label6.Visible = false;


            }


        }

        protected void Doctor_email_TextChanged(object sender, EventArgs e)
        {

        }

        protected void DoctorSchedule1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DoctorSchedule1.SelectedIndex == DoctorSchedule2.SelectedIndex || DoctorSchedule1.SelectedIndex == DoctorSchedule3.SelectedIndex)
            {
                Label6.Visible = true;
                Label6.Text = "Please do not select same day and time";
                Button_signup.Enabled = false;
            }
            else
            {
                Label6.Visible = false;
                Button_signup.Enabled = true;
            }
        }

        protected void Doctor_telephone_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button_signup_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            Label6.Visible = false;
            if (DoctorType.SelectedIndex != 0)
            {
                Label6.Visible = false;
                if (DoctorSchedule1.SelectedIndex != 0)
                {
                    Label6.Visible = false;

                    if (DoctorSchedule2.SelectedIndex != 0)
                    {
                        Label6.Visible = false;
                        if (DoctorSchedule3.SelectedIndex != 0)
                        {
                            string check = "SELECT * FROM Doctor WHERE DoctorEmail='" + Doctor_email.Text + "';";
                            OleDbCommand cmdcheck = new OleDbCommand(check, con);
                            OleDbDataReader dataReader = cmdcheck.ExecuteReader();
                            if (dataReader.HasRows)
                            {
                                Response.Write("<script>alert('Email already exists')</script>");
                            }
                            else
                            {
                                string query = "INSERT INTO Doctor (DoctorName, DoctorAddress, DoctorTelephone, DoctorType, DoctorEmail, DoctorPassword, Sched1, Sched2, Sched3, Status) VALUES('" + Doctor_name.Text + "', '" + Doctor_address.Text + "', '" + Doctor_telephone.Text + "', '" + DoctorType.SelectedValue + "', '" + Doctor_email.Text + "', '" + Doctor_password.Text + "', '" + Convert.ToString(DoctorSchedule1.SelectedValue) + "', '" + Convert.ToString(DoctorSchedule2.SelectedValue) + "', '" + Convert.ToString(DoctorSchedule3.SelectedValue) + "', 'Active');";
                                OleDbCommand cmd = new OleDbCommand(query, con);
                                cmd.ExecuteNonQuery();
                                con.Close();
                                //Response.Redirect("DoctorLogin.aspx");
                                Response.Write("<script>alert('Successfully Registered')</script>");
                                Label6.Visible = false;
                            }
                        }
                        else
                        {
                            Label6.Visible = true;
                            Label6.Text = "Please select doctor schedule 3";
                        }
                    }
                    else
                    {
                        Label6.Visible = true;
                        Label6.Text = "Please select doctor schedule 2";
                    }
                }
                else
                {
                    Label6.Visible = true;
                    Label6.Text = "Please select doctor schedule 1";
                }

            }
            else
            {
                Label6.Visible = true;
                Label6.Text = "Please select doctor type";
            }

        }

        void doctorsched()
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
                Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string query = "SELECT * FROM Schedule;";
            OleDbDataAdapter adapter = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            Dictionary<int, string> lst = new Dictionary<int, string>();

            foreach (DataRow dr in dt.Rows)
            {
                string id = dr["ID"].ToString();
                string day = dr["Day_Week"].ToString();
                string time = dr["Day_Time"].ToString();

                string combine = day + " - " + time;
                lst.Add(Convert.ToInt32(id), combine);

            }


            DoctorSchedule1.DataSource = lst;
            DoctorSchedule1.DataTextField = "Value";
            DoctorSchedule1.DataValueField = "Key";
            DoctorSchedule1.DataBind();

            DoctorSchedule2.DataSource = lst;
            DoctorSchedule2.DataTextField = "Value";
            DoctorSchedule2.DataValueField = "Key";
            DoctorSchedule2.DataBind();

            DoctorSchedule3.DataSource = lst;
            DoctorSchedule3.DataTextField = "Value";
            DoctorSchedule3.DataValueField = "Key";
            DoctorSchedule3.DataBind();

            DoctorSchedule1.Items.Insert(0, "-- SELECT DAY AND TIME (Schedule 1) --");
            DoctorSchedule2.Items.Insert(0, "-- SELECT DAY AND TIME (Schedule 2) --");
            DoctorSchedule3.Items.Insert(0, "-- SELECT DAY AND TIME (Schedule 3) --");

            con.Close();
        }

        protected void DoctorSchedule2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DoctorSchedule2.SelectedIndex == DoctorSchedule1.SelectedIndex || DoctorSchedule2.SelectedIndex == DoctorSchedule3.SelectedIndex)
            {
                Label6.Visible = true;
                Label6.Text = "Please do not select same day and time";
                Button_signup.Enabled = false;
            }
            else
            {
                Label6.Visible = false;
                Button_signup.Enabled = true;
            }
        }

        protected void DoctorSchedule3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DoctorSchedule3.SelectedIndex == DoctorSchedule2.SelectedIndex || DoctorSchedule3.SelectedIndex == DoctorSchedule1.SelectedIndex)
            {
                Label6.Visible = true;
                Label6.Text = "Please do not select same day and time";
                Button_signup.Enabled = false;
            }
            else
            {
                Label6.Visible = false;
                Button_signup.Enabled = true;
            }
        }

        protected void DoctorType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}