﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


namespace GROUP9_IT114L_MPFINAL.Admin_Pages
{
    public partial class AdminService1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Populate();
        }
        void Populate()
        {

            OleDbConnection con = new OleDbConnection("Provider =  Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = "Select ID,DoctorService from [Services]";
            cmd.Connection = con;
            OleDbDataReader rd = cmd.ExecuteReader();
            GridView1.DataSource = rd;
            GridView1.DataBind();
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

                e.Row.Cells[0].Text = "ID";
                e.Row.Cells[1].Text = "Doctor Service";
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}