﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace GROUP9_IT114L_MPFINAL.Admin_Pages
{
    public partial class AdminServiceRemove2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Populate();
        }

        protected void Button_removeinfo_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider =  Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string email = Session["AdminEmail"].ToString();
            string get_adminid = "SELECT ID FROM Admin WHERE AdminEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_adminid, con);
            string query_id = get_id.ExecuteScalar().ToString();
            string check_id = "SELECT * FROM Services WHERE ID=" + Convert.ToInt32(Doctor_removeid.Text) + ";";
            OleDbCommand cmd_check = new OleDbCommand(check_id, con);
            OleDbDataReader dr = cmd_check.ExecuteReader();
            if (dr.HasRows)
            {
                string query = "DELETE from Services WHERE ID=" + Convert.ToInt32(Doctor_removeid.Text) + ";";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Service deleted!')</script>");

            }
            else
            {
                Response.Write("<script>alert('ID does not exists!')</script>");

            }
            con.Close();
            Populate();
        }

        void Populate()
        {

            OleDbConnection con = new OleDbConnection("Provider =  Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = "Select ID,DoctorService from [Services]";
            cmd.Connection = con;
            OleDbDataReader rd = cmd.ExecuteReader();
            GridView1.DataSource = rd;
            GridView1.DataBind();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

                e.Row.Cells[0].Text = "ID";
                e.Row.Cells[1].Text = "Doctor Service";
            }
        }
    }
}