﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace GROUP9_IT114L_MPFINAL.Admin_Pages
{
    public partial class AdminServiceAdd2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Populate();
        }

        protected void Button_confirm_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider =  Microsoft.Jet.OLEDB.4.0; Data Source =" +
               Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string email = Session["AdminEmail"].ToString();
            string get_adminid = "SELECT ID FROM Admin WHERE AdminEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_adminid, con);
            string query_id = get_id.ExecuteScalar().ToString();
            string check_email = "SELECT * FROM Services WHERE DoctorService='" + Doctor_service.Text + "';";
            OleDbCommand cmd_check = new OleDbCommand(check_email, con);
            OleDbDataReader dr = cmd_check.ExecuteReader();
            if (dr.HasRows)
            {
                Response.Write("<script>alert('Service already exists')</script>");
            }
            else
            {
                string query = "INSERT INTO Services(DoctorService) VALUES ('" + Doctor_service.Text + "');";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Successfully Registered')</script>");

            }
            con.Close();

            Doctor_service.Text = "";
            Populate();
        }

        void Populate()
        {

            OleDbConnection con = new OleDbConnection("Provider =  Microsoft.Jet.OLEDB.4.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = "Select ID,DoctorService from [Services]";
            cmd.Connection = con;
            OleDbDataReader rd = cmd.ExecuteReader();
            GridView1.DataSource = rd;
            GridView1.DataBind();
        }
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

                e.Row.Cells[0].Text = "ID";
                e.Row.Cells[1].Text = "Doctor Service";
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}