﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace GROUP9_IT114L_MPFINAL.Doctor_Pages
{
    public partial class DoctorAppointment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                bindingData();
                Label4.Text = Session["DoctorEmail"].ToString();
                remarkserror.Visible= false;
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if(e.CommandName == "Cancelled")
            {
                if (remarks.Text == "")
                {
                    remarkserror.Visible = true;
                }
                else
                {
                    int index = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = GridView1.Rows[index];
                    int patientid = Convert.ToInt32(row.Cells[1].Text);
                    string date = row.Cells[4].Text;
                    string time = row.Cells[5].Text;
                    cancel(patientid, date, time);
                    bindingData();
                    remarkserror.Visible = false;
                }
            }
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[1].Text = "Patient ID";
                e.Row.Cells[2].Text = "Patient Name";
                e.Row.Cells[3].Text = "Requested Service";
                e.Row.Cells[4].Text = "Date";
                e.Row.Cells[5].Text = "Time";
                e.Row.Cells[6].Text = "Status of Appointment";
                e.Row.Cells[7].Text = "Remarks";

            }
        }

        void bindingData()
        {


            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));

            con.Open();

            string email = Session["DoctorEmail"].ToString();
            string query = "SELECT ID FROM Doctor WHERE DoctorEmail='" + email + "';";
            OleDbCommand cmd = new OleDbCommand(query, con);
            string id = cmd.ExecuteScalar().ToString();

            DataTable dt = new DataTable();
            string select = "Select PatientID, PatientName, DoctorService, SelectedDate, SelectedTime, status_appoint, RemarksAppoint FROM Appointment WHERE status_appoint = 'Approved' AND DoctorID="+Convert.ToInt32(id)+";";
            OleDbDataAdapter da = new OleDbDataAdapter(select, con);
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                GridView1.DataSource = dt;

                GridView1.DataBind();

            }
            else
            {
                DataTable to = new DataTable();
                GridView1.DataSource = to;
                GridView1.DataBind();
            }

            con.Close();

        }

     
        void cancel(int id, string date, string time)
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));

            con.Open();
            string query = "UPDATE Appointment set status_appoint='Cancelled by Doctor', RemarksAppoint='"+remarks.Text+"' WHERE PatientID=" + id + " AND SelectedDate='" + date + "' AND SelectedTime='" + time + "';";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}