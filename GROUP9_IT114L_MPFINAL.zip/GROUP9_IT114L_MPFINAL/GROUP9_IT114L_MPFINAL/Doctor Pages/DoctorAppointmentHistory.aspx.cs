﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GROUP9_IT114L_MPFINAL.Doctor_Pages
{
    public partial class DoctorAppointmentHistory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                Populate();
            }
        }
        void Populate()
        {
            string email = Session["DoctorEmail"].ToString();
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            string get_patientid = "SELECT ID FROM Doctor WHERE DoctorEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_patientid, con);
            string query_id = get_id.ExecuteScalar().ToString();

            DataTable dt = new DataTable();
            string select = "Select PatientID, PatientName, DoctorService, SelectedDate, SelectedTime, status_appoint FROM Appointment WHERE DoctorID=" + query_id + " AND status_appoint IN ('Approved', 'Pending', 'Cancelled by Doctor');";
            OleDbDataAdapter da = new OleDbDataAdapter(select, con);
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();

            }
            else
            {
                DataTable to = new DataTable();
                GridView1.DataSource = to;
                GridView1.DataBind();
            }
        }
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {

                e.Row.Cells[0].Text = "Patient ID";
                e.Row.Cells[1].Text = "Patient Name";
                e.Row.Cells[2].Text = "Requested Service";
                e.Row.Cells[3].Text = "Date";
                e.Row.Cells[4].Text = "Time";
                e.Row.Cells[5].Text = "Status of Appointment";

            }
        }
    }
}