﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace GROUP9_IT114L_MPFINAL.Doctor_Pages
{
    public partial class DoctorAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
                Server.MapPath("~/App_Data/MPIT114L.mdb"));
                con.Open();

                string email = Session["DoctorEmail"].ToString(); // pano to?, kukunin ko info nung sa patient @moses
                string check = "SELECT * FROM Doctor WHERE DoctorEmail='" + email + "';";
                OleDbCommand cmd = new OleDbCommand(check, con);
                OleDbDataReader read = cmd.ExecuteReader();
                read.Read();

                Doctor_name.Text = read["DoctorName"].ToString();
                Doctor_telephone.Text = read["DoctorTelephone"].ToString();
                Doctor_address.Text = read["DoctorAddress"].ToString();
                Doctor_email.Text = read["DoctorEmail"].ToString();

                            
                doctorsched();
                Label6.Visible = false;


                con.Close();
            }

            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

        }

        protected void Button_Update_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
              Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string email = Session["DoctorEmail"].ToString();
            string get_doctorid = "SELECT ID FROM Doctor WHERE DoctorEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_doctorid, con);
            string query_id = get_id.ExecuteScalar().ToString();
            Label6.Visible = false;
            if(DoctorType.SelectedIndex != 0)
            {
                Label6.Visible = false;
                if (DoctorSchedule1.SelectedIndex != 0)
                {
                    Label6.Visible = false;

                    if (DoctorSchedule2.SelectedIndex != 0)
                    {
                        Label6.Visible = false;
                        if (DoctorSchedule3.SelectedIndex!= 0)
                        {

                            OleDbCommand conn = new OleDbCommand("UPDATE Doctor set DoctorName='" + Doctor_name.Text + "', DoctorTelephone='" + Doctor_telephone.Text + "', DoctorAddress='" + Doctor_address.Text + "' , DoctorType='" + DoctorType.SelectedValue + "' , Sched1='" + Convert.ToString(DoctorSchedule1.SelectedValue) + "' , Sched2='" + Convert.ToString(DoctorSchedule2.SelectedValue) + "' , Sched3='" + Convert.ToString(DoctorSchedule3.SelectedValue) + "'WHERE ID = " + query_id + ";", con);
                            int r = conn.ExecuteNonQuery();

                            if (r > 0)
                            {
                                Response.Write("<script>alert('Doctor Details Updated')</script>");
                            }
                            else
                            {
                                Response.Write("<script>alert('The Information was  NOT Updated! Try Again!')</script>");
                            }
                            Label6.Visible = false;

                        }
                        else
                        {
                            Label6.Visible = true;
                            Label6.Text = "Please select doctor schedule 3";
                        }
                    }
                    else
                    {
                        Label6.Visible = true;
                        Label6.Text = "Please select doctor schedule 2";
                    }
                }
                else
                {
                    Label6.Visible = true;
                    Label6.Text = "Please select doctor schedule 1";
                }

            }
            else
            {
                Label6.Visible = true;
                Label6.Text = "Please select doctor type";
            }
            

           

            con.Close();
        }

        void doctorsched()
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
                Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string query = "SELECT * FROM Schedule;";
            OleDbDataAdapter adapter = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            Dictionary<int, string> lst = new Dictionary<int, string>();

            foreach (DataRow dr in dt.Rows)
            {
                string id = dr["ID"].ToString();
                string day = dr["Day_Week"].ToString();
                string time = dr["Day_Time"].ToString();

                string combine = day + " - " + time;
                lst.Add(Convert.ToInt32(id), combine);

            }


            DoctorSchedule1.DataSource = lst;
            DoctorSchedule1.DataTextField = "Value";
            DoctorSchedule1.DataValueField = "Key";
            DoctorSchedule1.DataBind();

            DoctorSchedule2.DataSource = lst;
            DoctorSchedule2.DataTextField = "Value";
            DoctorSchedule2.DataValueField = "Key";
            DoctorSchedule2.DataBind();

            DoctorSchedule3.DataSource = lst;
            DoctorSchedule3.DataTextField = "Value";
            DoctorSchedule3.DataValueField = "Key";
            DoctorSchedule3.DataBind();

            DoctorSchedule1.Items.Insert(0, "-- SELECT DAY AND TIME (Schedule 1) --");
            DoctorSchedule2.Items.Insert(0, "-- SELECT DAY AND TIME (Schedule 2) --");
            DoctorSchedule3.Items.Insert(0, "-- SELECT DAY AND TIME (Schedule 3) --");

            con.Close();
        }

        protected void DoctorSchedule1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DoctorSchedule1.SelectedIndex == DoctorSchedule2.SelectedIndex || DoctorSchedule1.SelectedIndex == DoctorSchedule3.SelectedIndex)
            {
                Label6.Visible = true;
                Label6.Text = "Please do not select same day and time";
            }
            else
            {
                Label6.Visible = false;
            }
        }

        protected void DoctorSchedule2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DoctorSchedule2.SelectedIndex == DoctorSchedule1.SelectedIndex || DoctorSchedule2.SelectedIndex == DoctorSchedule3.SelectedIndex)
            {
                Label6.Visible = true;
                Label6.Text = "Please do not select same day and time";
            }
            else
            {
                Label6.Visible = false;
            }
        }

        protected void DoctorSchedule3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DoctorSchedule3.SelectedIndex == DoctorSchedule2.SelectedIndex || DoctorSchedule3.SelectedIndex == DoctorSchedule1.SelectedIndex)
            {
                Label6.Visible = true;
                Label6.Text = "Please do not select same day and time";
            }
            else
            {
                Label6.Visible = false;
            }
        }

        protected void Button_Clear_Click(object sender, EventArgs e)
        {
            Doctor_name.Text = "";
            Doctor_telephone.Text = "";
            Doctor_address.Text = "";
        }

        protected void DoctorType_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}