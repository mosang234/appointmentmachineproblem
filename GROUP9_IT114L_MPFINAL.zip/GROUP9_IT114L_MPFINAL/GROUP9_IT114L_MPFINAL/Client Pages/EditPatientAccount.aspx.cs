﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace GROUP9_IT114L_MPFINAL.Master_Pages
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button_confirm_Click(object sender, EventArgs e)
        {
            OleDbConnection formconn = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
                Server.MapPath("~/App_Data/MPIT114L.mdb"));
            formconn.Open();
            string strUpdate = "UPDATE [Patient] SET [PatientName]=?, [PatientAddress]=?, [PatientTelephone]=?, '" +
                "[PatientEmail]=?, [PatientPassword]=?, WHERE [ID]=?";

            OleDbCommand updatecmd = new OleDbCommand(strUpdate, formconn);
            updatecmd.Parameters.AddWithValue("PatientName", Patient_name.Text);
            updatecmd.Parameters.AddWithValue("PatientAddress", Patient_address.Text);
            updatecmd.Parameters.AddWithValue("PatientTelephone", Patient_telephone.Text);
            updatecmd.Parameters.AddWithValue("PatientEmail", Patient_email.Text);
            updatecmd.Parameters.AddWithValue("PatientPassword", Patient_password.Text);


            int r = updatecmd.ExecuteNonQuery();
            formconn.Close();
            if (r > 0)
            {
                Response.Write("<script>alert('Patient details updated')</script>");
            }
            else
            {
                Response.Write("<script>alert('The information was  NOT updated! Try Again!')</script>");
            }



            Patient_name.Text = "";
            Patient_address.Text = "";
            Patient_telephone.Text = "";
            Patient_email.Text = "";
            Patient_password.Text = "";
            Response.Redirect("PatientAppointment.aspx");
        }
    }
}