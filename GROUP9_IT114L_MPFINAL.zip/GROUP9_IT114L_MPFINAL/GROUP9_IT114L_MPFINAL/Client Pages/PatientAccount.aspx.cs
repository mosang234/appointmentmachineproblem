﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace GROUP9_IT114L_MPFINAL.Client_Pages
{
    public partial class PatientAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
                Server.MapPath("~/App_Data/MPIT114L.mdb"));
                con.Open();

                string email = Session["PatientEmail"].ToString(); // pano to?, kukunin ko info nung sa patient @moses
                string check = "SELECT * FROM Patient WHERE PatientEmail='" + email + "';";
                OleDbCommand cmd = new OleDbCommand(check, con);
                OleDbDataReader read = cmd.ExecuteReader();
                read.Read();

                Patient_name.Text = read["PatientName"].ToString();
                Patient_telephone.Text = read["PatientTelephone"].ToString();
                Patient_address.Text = read["PatientAddress"].ToString();
                Patient_email.Text = read["PatientEmail"].ToString();

                con.Close();
            }

            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Button_Update_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
              Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string email = Session["PatientEmail"].ToString();
            string get_patientid = "SELECT ID FROM Patient WHERE PatientEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_patientid, con);
            string query_id = get_id.ExecuteScalar().ToString();

            OleDbCommand conn = new OleDbCommand("UPDATE Patient set PatientName='" + Patient_name.Text + "', PatientTelephone='" + Patient_telephone.Text + "', PatientAddress='" + Patient_address.Text + "' WHERE ID = " + query_id + ";", con);
            int r = conn.ExecuteNonQuery();

            if (r > 0)
            {
                Response.Write("<script>alert('Patient Details Updated')</script>");
            }
            else
            {
                Response.Write("<script>alert('The Information was  NOT Updated! Try Again!')</script>");
            }

            con.Close();
        }

        protected void Button_Clear_Click(object sender, EventArgs e)
        {
            Patient_name.Text = "";
            Patient_telephone.Text = "";
            Patient_address.Text = "";
        }
    }
}