﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GROUP9_IT114L_MPFINAL.Client_Pages
{
    public partial class PatientSignup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Button_signup_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" +
             Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            string check_email = "SELECT * FROM Patient WHERE PatientEmail='" + Patient_email.Text + "';";
            OleDbCommand cmd_check = new OleDbCommand(check_email,con); 
            OleDbDataReader dr = cmd_check.ExecuteReader();
            if(dr.HasRows)
            {
                Response.Write("<script>alert('Email already exists')</script>");
            }
            else
            {
                string query = "INSERT INTO Patient(PatientName, PatientAddress, PatientTelephone, PatientEmail, PatientPassword) VALUES ('" + Patient_name.Text + "', '" + Patient_address.Text + "', '" + Patient_telephone.Text + "', '" + Patient_email.Text + "', '" + Patient_password.Text + "');";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Successfully Registered')</script>");
            }

            
            con.Close();
            Response.Redirect("PatientLogin.aspx");

            Patient_name.Text = "";
            Patient_address.Text = "";
            Patient_telephone.Text = "";
            Patient_email.Text = "";
            Patient_password.Text = "";

            
        }

      
    }
}