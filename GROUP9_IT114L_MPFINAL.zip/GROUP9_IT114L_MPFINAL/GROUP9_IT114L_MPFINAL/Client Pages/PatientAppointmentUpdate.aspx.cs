﻿using GROUP9_IT114L_MPFINAL.Main_Pages;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace GROUP9_IT114L_MPFINAL.Client_Pages
{
    public partial class PatientAppointmentUpdate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                Calendar1.DayRender += new DayRenderEventHandler(DayRenderCalendar);

                string id = Session["DoctorID"].ToString();
                string name = Session["DoctorName"].ToString();
                Doctor_name.Text = name;
                Doctor_id.Text = id;
                Doctor_id.Enabled = false; Doctor_name.Enabled = false;
                availabletimedrop.Enabled = false ;
                doctorservice.Enabled = false;
            }
        }

        void currentvalue()
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            /*
            string email = Session["PatientEmail"].ToString();
            string get_patientid = "SELECT ID FROM Patient WHERE PatientEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_patientid, con);
            string query_id = get_id.ExecuteScalar().ToString();
            */
            
            string id = Session["DoctorID"].ToString();
           

            string query = "SELECT * FROM Services WHERE DoctorType=(SELECT DoctorType FROM Doctor WHERE ID =" + Convert.ToInt32(id) + ");";
            OleDbDataAdapter adapt = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            doctorservice.DataSource = dt;
            doctorservice.DataTextField = "DoctorService";
            doctorservice.DataValueField = "ID";
            doctorservice.DataBind();


            con.Close();

            

            doctorservice.SelectedIndex = 0;
        }

        void availabletime()
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
           Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();
            string id = Session["DoctorID"].ToString();


            List<int> list1 = new List<int>();
            List<int> list2 = new List<int>();
            List<int> list4 = new List<int>();
            Dictionary<int, string> dictionary = new Dictionary<int, string>();

            //Get the doctor's schedule 2 list
            string doctor = "SELECT Sched1, Sched2, Sched3 FROM Doctor WHERE ID=" + Convert.ToInt32(id);
            OleDbCommand cmd = new OleDbCommand(doctor, con);
            OleDbDataReader get_doctor = cmd.ExecuteReader();

            get_doctor.Read();
            list1.Add(Convert.ToInt32(get_doctor["Sched1"]));
            list1.Add(Convert.ToInt32(get_doctor["Sched2"]));
            list1.Add(Convert.ToInt32(get_doctor["Sched3"]));


            list4.Add(Convert.ToInt32(get_doctor["Sched1"]));
            list4.Add(Convert.ToInt32(get_doctor["Sched2"]));
            list4.Add(Convert.ToInt32(get_doctor["Sched3"]));

            string timetaken = "SELECT SchedID FROM Appointment WHERE status_appoint IN ('Approved', 'Pending') AND DoctorID=" + Convert.ToInt32(id) + "AND SelectedDate='" + Calendar1.SelectedDate.ToShortDateString() + "';";
            OleDbCommand cmd2 = new OleDbCommand(timetaken, con);
            OleDbDataReader get_time = cmd2.ExecuteReader();
            if (get_time.HasRows)
            {
                while (get_time.Read())
                {
                    list2.Add(Convert.ToInt32(get_time["SchedID"]));
                }
            }

            for (int j = 0; j < list2.Count(); j++)
            {
                if (list1.Contains(list2[j]))
                {
                    list4.RemoveAt(list4.IndexOf(list2[j]));
                }

            }


            //lalagay sa dictionary lahat ng available time

            dictionary.Clear();
            for (int i = 0; i < list4.Count(); i++)
            {
                string query = "SELECT ID, Day_Time FROM Schedule WHERE ID=" + list4[i] + " AND Day_Week='" + Calendar1.SelectedDate.DayOfWeek.ToString() + "';";
                OleDbCommand cmd1 = new OleDbCommand(query, con);
                OleDbDataReader dr = cmd1.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    dictionary.Add(Convert.ToInt32(dr["ID"]), dr["Day_Time"].ToString());
                }


            }

            if (dictionary.Count > 0)
            {


                availabletimedrop.DataSource = dictionary;
                availabletimedrop.DataTextField = "Value";
                availabletimedrop.DataValueField = "Key";
                availabletimedrop.DataBind();

                availabletimedrop.Items.Insert(0, "-- SELECT TIME --");

            }
            else
            {
                DataTable dto = new DataTable();
                availabletimedrop.DataSource = dto;
                availabletimedrop.DataBind();
                availabletimedrop.Items.Insert(0, "-- NO AVAILABLE TIME --");
            }

        }

        protected void Button_confirm_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            string email = Session["PatientEmail"].ToString();
            string get_patientid = "SELECT ID FROM Patient WHERE PatientEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_patientid, con);
            string query_id = get_id.ExecuteScalar().ToString();

            
         
            string id = Session["DoctorID"].ToString();
            string date = Session["SelectedDate"].ToString();
            string time = Session["SelectedTime"].ToString();


            string update = "UPDATE Appointment set DoctorService='" + doctorservice.SelectedItem.Text+"' , SelectedDate='"+Calendar1.SelectedDate.ToShortDateString()+"', SelectedTime='"+availabletimedrop.SelectedItem.Text+"', status_appoint='Approved', SchedID="+availabletimedrop.SelectedValue +", RemarksAppoint=null WHERE PatientID =" + Convert.ToInt32(query_id) + " AND DoctorID=" + Convert.ToInt32(id) +"AND status_appoint='Cancelled by Doctor'" +" AND SelectedDate='"+date+"' AND SelectedTime='"+time+"';";
            OleDbCommand cmd = new OleDbCommand(update, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('Appointment Updated Successfully')</script>");

            Response.Redirect("PatientAppointment.aspx");
          
        }

        protected void Button_cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("PatientAppointment.aspx");
        }

        protected void availabletimedrop_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            Calendar1.DayRender += new DayRenderEventHandler(DayRenderCalendar);
            currentvalue();
            doctorservice.Enabled = true;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
           
            Calendar1.DayRender += new DayRenderEventHandler(DayRenderCalendar);
            availabletime();
            availabletimedrop.Enabled = true;
        }

        protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        {

        }








        void DayRenderCalendar(object sender, DayRenderEventArgs e)
        {

            e.Day.IsSelectable = false;
            e.Cell.ForeColor = System.Drawing.Color.DarkGray;



            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            List<int> list1 = new List<int>();

            List<int> list5 = new List<int>();

            List<int> list2 = new List<int>();

            string id = Session["DoctorID"].ToString();

            string sched_date = "SELECT SelectedDate FROM Appointment WHERE DoctorID=" + Convert.ToInt32(id) + ";";
            OleDbCommand sched_cmd = new OleDbCommand(sched_date, con);
            OleDbDataReader date_dr = sched_cmd.ExecuteReader();
            List<string> list_date = new List<string>();
            while (date_dr.Read())
            {
                list_date.Add(date_dr["SelectedDate"].ToString());
            }
            List<string> list_date_nodup = list_date.Distinct().ToList();








            for (int i = 0; i < list_date_nodup.Count(); i++)
            {
                list1.Clear();
                list2.Clear();
                list5.Clear();

                string doctor = "SELECT Sched1, Sched2, Sched3 FROM Doctor WHERE ID=" + Convert.ToInt32(id);
                OleDbCommand cmd = new OleDbCommand(doctor, con);
                OleDbDataReader get_doctor = cmd.ExecuteReader();

                get_doctor.Read();
                list1.Add(Convert.ToInt32(get_doctor["Sched1"]));
                list1.Add(Convert.ToInt32(get_doctor["Sched2"]));
                list1.Add(Convert.ToInt32(get_doctor["Sched3"]));

                list5.Add(Convert.ToInt32(get_doctor["Sched1"]));
                list5.Add(Convert.ToInt32(get_doctor["Sched2"]));
                list5.Add(Convert.ToInt32(get_doctor["Sched3"]));

                string timetaken = "SELECT SchedID FROM Appointment WHERE status_appoint IN ('Approved', 'Pending') AND DoctorID=" + Convert.ToInt32(id) + "AND SelectedDate='" + Convert.ToDateTime(list_date[i]).ToShortDateString() + "';";
                OleDbCommand cmd2 = new OleDbCommand(timetaken, con);
                OleDbDataReader get_time = cmd2.ExecuteReader();
                if (get_time.HasRows)
                {
                    while (get_time.Read())
                    {
                        list2.Add(Convert.ToInt32(get_time["SchedID"]));
                    }

                    //Removing the sched from the list 
                    for (int j = 0; j < list2.Count(); j++)
                    {
                        if (list1.Contains(list2[j]))
                        {
                            list5.RemoveAt(list5.IndexOf(list2[j]));
                        }


                    }
                }





                Dictionary<int, string> dictionary = new Dictionary<int, string>();
                dictionary.Clear();
                for (int l = 0; l < list5.Count(); l++)
                {
                    string query = "SELECT ID, Day_Time FROM Schedule WHERE ID=" + list5[l] + " AND Day_Week='" + Convert.ToDateTime(list_date[i]).DayOfWeek.ToString() + "';";
                    OleDbCommand cmd1 = new OleDbCommand(query, con);
                    OleDbDataReader dr = cmd1.ExecuteReader();

                    if (dr.HasRows)
                    {
                        dr.Read();
                        dictionary.Add(Convert.ToInt32(dr["ID"]), dr["Day_Time"].ToString());
                    }


                }

                if (e.Day.Date == Convert.ToDateTime(list_date[i]))
                {

                    if (dictionary.Count() > 0)
                    {
                        e.Cell.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        e.Cell.BackColor = System.Drawing.Color.Magenta;
                    }
                }


            }

            //Selectable Dates based on Doctor Schedule;
            // List<string> list_day = new List<string>();
            for (int k = 0; k < list1.Count(); k++)
            {
                string dayweek = "SELECT Day_Week FROM Schedule WHERE ID=" + list1[k] + ";";
                OleDbCommand cmd_day = new OleDbCommand(dayweek, con);
                OleDbDataReader dr_day = cmd_day.ExecuteReader();

                dr_day.Read();
                if (e.Day.Date < DateTime.Now)
                {

                    e.Day.IsSelectable = false;
                    e.Cell.ForeColor = System.Drawing.Color.LightGoldenrodYellow;


                }
                else
                {
                    if (dr_day["Day_Week"].ToString() == "Monday")
                    {
                        if (e.Day.Date.DayOfWeek == DayOfWeek.Monday)
                        {


                            e.Day.IsSelectable = true;
                            e.Cell.ForeColor = System.Drawing.Color.Green;


                        }
                    }

                    if (dr_day["Day_Week"].ToString() == "Tuesday")
                    {
                        if (e.Day.Date.DayOfWeek == DayOfWeek.Tuesday)
                        {


                            e.Day.IsSelectable = true;
                            e.Cell.ForeColor = System.Drawing.Color.Green;


                        }
                    }

                    if (dr_day["Day_Week"].ToString() == "Wednesday")
                    {
                        if (e.Day.Date.DayOfWeek == DayOfWeek.Wednesday)
                        {


                            e.Day.IsSelectable = true;
                            e.Cell.ForeColor = System.Drawing.Color.Green;


                        }
                    }

                    if (dr_day["Day_Week"].ToString() == "Thursday")
                    {
                        if (e.Day.Date.DayOfWeek == DayOfWeek.Thursday)
                        {


                            e.Day.IsSelectable = true;
                            e.Cell.ForeColor = System.Drawing.Color.Green;


                        }
                    }

                    if (dr_day["Day_Week"].ToString() == "Friday")
                    {
                        if (e.Day.Date.DayOfWeek == DayOfWeek.Friday)
                        {


                            e.Day.IsSelectable = true;
                            e.Cell.ForeColor = System.Drawing.Color.Green;


                        }
                    }
                }

                
            }
            


            con.Close();
        }

        protected void doctorservice_SelectedIndexChanged(object sender, EventArgs e)
        {
            Calendar1.DayRender += new DayRenderEventHandler(DayRenderCalendar);
        }

        protected void Calendar1_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
        {
            Calendar1.DayRender += new DayRenderEventHandler(DayRenderCalendar);
            Calendar1.SelectedDates.Clear();
        }
    }
}