﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace GROUP9_IT114L_MPFINAL.Client_Pages
{
    public partial class PatientAppointment : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            Label5.Visible = false;
            Label4.Text = Session["PatientEmail"].ToString();
            if (!this.IsPostBack)
            {
                Populate();
                bindingData();
                DropDownList2.Enabled = false;
                DropDownList3.Enabled = false;
                Calendar1.Enabled = false;
                
                Button_signup.Enabled = false;
                
            }
            
        }

        void Populate()
        {

            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
           Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            string com = "SELECT * FROM Doctor WHERE Status='Active';";
            OleDbDataAdapter adapt = new OleDbDataAdapter(com, con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            DropDownList1.DataSource = dt;
            DropDownList1.DataTextField = "DoctorName";
            DropDownList1.DataValueField = "ID";
            DropDownList1.DataBind();


            con.Close();
            DropDownList1.Items.Insert(0, "-- SELECT DOCTOR --");

        }

        void sched()
        {

            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
           Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            if (DropDownList1.SelectedIndex != 0)
            {
                

                List<int> list1 = new List<int>();
                List<int> list2 = new List<int>();
                List<int> list4 = new List<int>();
                Dictionary<int, string> dictionary = new Dictionary<int, string>();

                //Get the doctor's schedule 2 list
                string doctor = "SELECT Sched1, Sched2, Sched3 FROM Doctor WHERE ID=" + DropDownList1.SelectedValue;
                OleDbCommand cmd = new OleDbCommand(doctor, con);
                OleDbDataReader get_doctor = cmd.ExecuteReader();

                get_doctor.Read();
                list1.Add(Convert.ToInt32(get_doctor["Sched1"]));
                list1.Add(Convert.ToInt32(get_doctor["Sched2"]));
                list1.Add(Convert.ToInt32(get_doctor["Sched3"]));


                list4.Add(Convert.ToInt32(get_doctor["Sched1"]));
                list4.Add(Convert.ToInt32(get_doctor["Sched2"]));
                list4.Add(Convert.ToInt32(get_doctor["Sched3"]));


                //Get the sched id from appointment table

                string timetaken = "SELECT SchedID FROM Appointment WHERE status_appoint IN ('Approved', 'Pending') AND DoctorID=" + DropDownList1.SelectedValue + "AND SelectedDate='" + Calendar1.SelectedDate.ToShortDateString() + "';";
                OleDbCommand cmd2 = new OleDbCommand(timetaken, con);
                OleDbDataReader get_time = cmd2.ExecuteReader();
                if (get_time.HasRows)
                {
                    while (get_time.Read())
                    {
                        list2.Add(Convert.ToInt32(get_time["SchedID"]));
                    }
                }

                //Removing the sched from the list 
                for (int j = 0; j < list2.Count(); j++)
                {
                    if (list1.Contains(list2[j]))
                    {
                        list4.RemoveAt(list4.IndexOf(list2[j]));
                    }

                }


                //lalagay sa dictionary lahat ng available time

                dictionary.Clear();
                for (int i = 0; i < list4.Count(); i++)
                {
                    string query = "SELECT ID, Day_Time FROM Schedule WHERE ID=" + list4[i] + " AND Day_Week='" + Calendar1.SelectedDate.DayOfWeek.ToString() + "';";
                    OleDbCommand cmd1 = new OleDbCommand(query, con);
                    OleDbDataReader dr = cmd1.ExecuteReader();

                    if (dr.HasRows)
                    {
                        dr.Read();
                        dictionary.Add(Convert.ToInt32(dr["ID"]), dr["Day_Time"].ToString());
                    }


                }

                //Check if there is available time 
                if (dictionary.Count > 0)
                {


                    DropDownList2.DataSource = dictionary;
                    DropDownList2.DataTextField = "Value";
                    DropDownList2.DataValueField = "Key";
                    DropDownList2.DataBind();

                    DropDownList2.Items.Insert(0, "-- SELECT TIME --");

                }
                else
                {
                    DataTable dto = new DataTable();
                    DropDownList2.DataSource = dto;
                    DropDownList2.DataBind();
                    DropDownList2.Items.Insert(0, "-- NO AVAILABLE TIME --");
                }
              
            }
            else
            {
                DropDownList1.SelectedIndex = 0;
                DropDownList2.Items.Clear();
            }


        }

        public List<string> list()
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
           Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            List<string> lst = new List<string>();
            if (DropDownList1.SelectedIndex != 0)
            {

                string com = "SELECT Sched1, Sched2, Sched3 FROM Doctor WHERE ID=" + int.Parse(DropDownList1.SelectedValue) + ";";
                OleDbDataAdapter adapter = new OleDbDataAdapter(com, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                foreach (DataRow row in dt.Rows)
                {
                    //Add values to Dictionary
                    string val1 = row[0].ToString(); // Sched1
                    string sched_day_week1 = "SELECT Day_Week FROM Schedule WHERE ID=" + Convert.ToInt32(val1) + ";";
                    OleDbCommand ha2 = new OleDbCommand(sched_day_week1, con);
                    string result2 = ha2.ExecuteScalar().ToString();

                    string val2 = row[1].ToString(); // Sched2
                    string sched_day_week2 = "SELECT Day_Week FROM Schedule WHERE ID=" + Convert.ToInt32(val2) + ";";
                    OleDbCommand ha3 = new OleDbCommand(sched_day_week2, con);
                    string result3 = ha3.ExecuteScalar().ToString();

                    string val3 = row[2].ToString(); // Sched3
                    string sched_day_week3 = "SELECT Day_Week FROM Schedule WHERE ID=" + Convert.ToInt32(val3) + ";";
                    OleDbCommand ha4 = new OleDbCommand(sched_day_week3, con);
                    string result4 = ha4.ExecuteScalar().ToString();

                    lst.Add(result2);
                    lst.Add(result3);
                    lst.Add(result4);
                }
            }
            else
            {
                DropDownList1.SelectedIndex = 0;
                DropDownList2.Items.Clear();
            }
            con.Close();
            return lst;

        }

        private void cancelbutton(int id, string date, string time)
        {
            string email = Session["PatientEmail"].ToString();
           
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
           Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            string get_patientid = "SELECT ID FROM Patient WHERE PatientEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_patientid, con);
            string query_id = get_id.ExecuteScalar().ToString();


            string query = "UPDATE Appointment set status_appoint='Cancelled by Patient' WHERE DoctorID=" + id + " AND SelectedTime='" + time + "' AND SelectedDate='" + date +"' AND PatientID="+Convert.ToInt32(query_id) +";";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void bindingData()
        {
            string email = Session["PatientEmail"].ToString();
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
           Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            string get_patientid = "SELECT ID FROM Patient WHERE PatientEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_patientid, con);
            string query_id = get_id.ExecuteScalar().ToString();

            DataTable dt = new DataTable();
            string select = "Select DoctorID, DoctorName, DoctorService, SelectedDate, SelectedTime, status_appoint, RemarksAppoint FROM Appointment WHERE PatientID=" + query_id + " AND status_Appoint NOT IN ('Cancelled by Patient' , 'Hide');";
            OleDbDataAdapter da = new OleDbDataAdapter(select, con);
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();

            }
            else
            {
                DataTable to = new DataTable();
                GridView1.DataSource = to;
                GridView1.DataBind();
            }


            con.Close();

        }

        void bindServices()
        {
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
           Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            string query = "SELECT * FROM Services WHERE DoctorType=(SELECT DoctorType FROM Doctor WHERE ID =" + DropDownList1.SelectedValue + ");";
            OleDbDataAdapter adapt = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            DropDownList3.DataSource = dt;
            DropDownList3.DataTextField = "DoctorService";
            DropDownList3.DataValueField = "ID";
            DropDownList3.DataBind();


            con.Close();
            DropDownList3.Items.Insert(0, "-- SELECT SERVICE --");
        }





        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            DropDownList2.Enabled = false;
            DropDownList3.Enabled = false;
            Calendar1.Enabled = true;
            Calendar1.SelectedDates.Clear();
            list();
            Calendar1.DayRender += new DayRenderEventHandler(DayRenderCalendar);
            bindingData();
    



        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

            DropDownList3.Enabled = true;
            bindingData();
            Calendar1.DayRender += new DayRenderEventHandler(DayRenderCalendar);

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            Calendar1.DayRender += new DayRenderEventHandler(DayRenderCalendar);
            availabletime();
            bindServices();
            sched();
            

            bindingData();
            Button_signup.Enabled = false;
            DropDownList2.Enabled = true; 
            



        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button_signup_Click(object sender, EventArgs e)
        {
            string email = Session["PatientEmail"].ToString();
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            string get_patientid = "SELECT ID FROM Patient WHERE PatientEmail='" + email + "';";
            OleDbCommand get_id = new OleDbCommand(get_patientid, con);
            string query_id = get_id.ExecuteScalar().ToString();

            string get_patientname = "SELECT PatientName FROM Patient WHERE PatientEmail='" + email + "';";
            OleDbCommand get_name = new OleDbCommand(get_patientname, con);
            string query_name = get_name.ExecuteScalar().ToString();

            string query = "Insert into Appointment (DoctorService, DoctorID, PatientID, DoctorName, PatientName, SchedID, SelectedDate, SelectedTime, status_appoint) Values ('" + DropDownList3.SelectedItem.Text + "', " + DropDownList1.SelectedValue + "," + Convert.ToInt32(query_id) + ", '" + DropDownList1.SelectedItem.Text + "' , '" + query_name + "' ," + DropDownList2.SelectedValue + ",'" + Calendar1.SelectedDate.ToShortDateString() + "','" + DropDownList2.SelectedItem.Text + "'," + "'Approved'" + ");";
            OleDbCommand insert = new OleDbCommand(query, con);
            insert.ExecuteNonQuery();
            Response.Write("<script>alert('Successfully Appointed')</script>");
            DropDownList1.SelectedIndex = 0;
            DropDownList2.SelectedIndex = 0;
            DropDownList3.SelectedIndex = 0;


            Calendar1.Enabled = false;

            DropDownList2.Enabled = false;
            DropDownList3.Enabled = false;
            Button_signup.Enabled = false;
            Calendar1.SelectedDates.Clear();

            
            DataTable dto = new DataTable();
            GridViewAvailable.DataSource = dto;
            GridViewAvailable.DataBind();



            con.Close();
            bindingData();

           

            

        }

        protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        {
    
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[0].Text = "--------";
                e.Row.Cells[1].Text = "--------";
                e.Row.Cells[2].Text = "Doctor ID";
                e.Row.Cells[3].Text = "Doctor Name";
                e.Row.Cells[4].Text = "Doctor Service";
                e.Row.Cells[5].Text = "Date";
                e.Row.Cells[6].Text = "Time";
                e.Row.Cells[7].Text = "Status of Appointment";
                e.Row.Cells[8].Text = "Remarks";

            }


            if (e.Row.RowType == DataControlRowType.DataRow)
            {
               

                if (e.Row.Cells[7].Text == "Approved")
                {
                    e.Row.Cells[1].Text = " ";
                }

                

            }
        }

        protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
        {

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Cancelled")
            {

                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];


                int doctorid = Convert.ToInt32(row.Cells[2].Text);
                string date = row.Cells[5].Text;
                string time = row.Cells[6].Text;
                cancelbutton(doctorid, date, time);

                bindingData();


            }
            if (e.CommandName == "Editted")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];

                int doctorid = Convert.ToInt32(row.Cells[2].Text);
                string name = row.Cells[3].Text;
                string date = row.Cells[5].Text;
                string time = row.Cells[6].Text;
                Session["Doctorname"] = name;
                Session["DoctorID"] = doctorid;
                Session["SelectedDate"] = date;
                Session["SelectedTime"] = time;
                Response.Redirect("PatientAppointmentUpdate.aspx");
            }
        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindingData();
            Button_signup.Enabled = true;
            Calendar1.DayRender += new DayRenderEventHandler(DayRenderCalendar);
            
        }

        void availabletime()
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            List<int> list1 = new List<int>();
            List<int> list2 = new List<int>();
            List<int> list4 = new List<int>();
            Dictionary<int, string> dictionary = new Dictionary<int, string>();

            //Get the doctor's schedule 2 list
            string doctor = "SELECT Sched1, Sched2, Sched3 FROM Doctor WHERE ID=" + DropDownList1.SelectedValue;
            OleDbCommand cmd = new OleDbCommand(doctor, con);
            OleDbDataReader get_doctor = cmd.ExecuteReader();

            get_doctor.Read();
            list1.Add(Convert.ToInt32(get_doctor["Sched1"]));
            list1.Add(Convert.ToInt32(get_doctor["Sched2"]));
            list1.Add(Convert.ToInt32(get_doctor["Sched3"]));


            list4.Add(Convert.ToInt32(get_doctor["Sched1"]));
            list4.Add(Convert.ToInt32(get_doctor["Sched2"]));
            list4.Add(Convert.ToInt32(get_doctor["Sched3"]));


            //Get the sched id from appointment table
            
            string timetaken = "SELECT SchedID FROM Appointment WHERE status_appoint IN ('Approved', 'Pending') AND DoctorID=" + DropDownList1.SelectedValue + "AND SelectedDate='"+ Calendar1.SelectedDate.ToShortDateString()+"';";
            OleDbCommand cmd2 = new OleDbCommand(timetaken, con);
            OleDbDataReader get_time = cmd2.ExecuteReader();
            if (get_time.HasRows)
            {
                while (get_time.Read())
                {
                    list2.Add(Convert.ToInt32(get_time["SchedID"]));
                }
            }
            
            //Removing the sched from the list 
            for(int j = 0; j<list2.Count(); j++) 
            {
                if (list1.Contains(list2[j]))
                {
                    list4.RemoveAt(list4.IndexOf(list2[j]));
                }
                
            }


            //lalagay sa dictionary lahat ng available time
            
            dictionary.Clear();
            for (int i = 0; i < list4.Count(); i++)
            {
                string query = "SELECT ID, Day_Time FROM Schedule WHERE ID=" + list4[i] + " AND Day_Week='" + Calendar1.SelectedDate.DayOfWeek.ToString() + "';";
                OleDbCommand cmd1 = new OleDbCommand(query, con);
                OleDbDataReader dr = cmd1.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    dictionary.Add(Convert.ToInt32(dr["ID"]), dr["Day_Time"].ToString());
                }


            }

            //Check if there is available time 
            if (dictionary.Count > 0)
            {


                DataTable dt = new DataTable();
                dt.Columns.Add("Available Time");

                
                foreach (var key in dictionary.Keys)
                {
                    dt.Rows.Add(dictionary[key]);
                }
               
                    GridViewAvailable.DataSource = dt;
                GridViewAvailable.DataBind();

            }
            else
            {
                DataTable dto = new DataTable();
                GridViewAvailable.DataSource = dto;
                GridViewAvailable.DataBind();

            }
            con.Close();

        }

        void DayRenderCalendar(object sender, DayRenderEventArgs e)
        {

            e.Day.IsSelectable = false;
            e.Cell.ForeColor = System.Drawing.Color.DarkGray;



            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" +
            Server.MapPath("~/App_Data/MPIT114L.mdb"));
            con.Open();

            List<int> list1 = new List<int>();

            List<int> list5 = new List<int>();

            List<int> list2 = new List<int>();

            

            string sched_date = "SELECT SelectedDate FROM Appointment WHERE DoctorID=" + DropDownList1.SelectedValue +";";
            OleDbCommand sched_cmd = new OleDbCommand(sched_date, con);
            OleDbDataReader date_dr = sched_cmd.ExecuteReader();
            List<string> list_date = new List<string>();
            while (date_dr.Read())
            {
                list_date.Add(date_dr["SelectedDate"].ToString());
            }
            List<string> list_date_nodup = list_date.Distinct().ToList();



            

            


            for (int i = 0; i < list_date_nodup.Count(); i++)
            {
                list1.Clear();
                list2.Clear();
                list5.Clear();

                string doctor = "SELECT Sched1, Sched2, Sched3 FROM Doctor WHERE ID=" + DropDownList1.SelectedValue;
                OleDbCommand cmd = new OleDbCommand(doctor, con);
                OleDbDataReader get_doctor = cmd.ExecuteReader();

                get_doctor.Read();
                list1.Add(Convert.ToInt32(get_doctor["Sched1"]));
                list1.Add(Convert.ToInt32(get_doctor["Sched2"]));
                list1.Add(Convert.ToInt32(get_doctor["Sched3"]));

                list5.Add(Convert.ToInt32(get_doctor["Sched1"]));
                list5.Add(Convert.ToInt32(get_doctor["Sched2"]));
                list5.Add(Convert.ToInt32(get_doctor["Sched3"]));

                string timetaken = "SELECT SchedID FROM Appointment WHERE status_appoint IN ('Approved', 'Pending') AND DoctorID=" + DropDownList1.SelectedValue + "AND SelectedDate='" + Convert.ToDateTime(list_date[i]).ToShortDateString() + "';";
                OleDbCommand cmd2 = new OleDbCommand(timetaken, con);
                OleDbDataReader get_time = cmd2.ExecuteReader();
                if (get_time.HasRows)
                {
                    while (get_time.Read())
                    {
                        list2.Add(Convert.ToInt32(get_time["SchedID"]));
                    }

                    //Removing the sched from the list 
                    for (int j = 0; j < list2.Count(); j++)
                    {
                        if (list1.Contains(list2[j]))
                        {
                            list5.RemoveAt(list5.IndexOf(list2[j]));
                        }


                    }
                }

              



                Dictionary<int, string> dictionary = new Dictionary<int, string>();
                dictionary.Clear();
                for (int l = 0; l < list5.Count(); l++)
                {
                    string query = "SELECT ID, Day_Time FROM Schedule WHERE ID=" + list5[l] + " AND Day_Week='" + Convert.ToDateTime(list_date[i]).DayOfWeek.ToString() + "';";
                    OleDbCommand cmd1 = new OleDbCommand(query, con);
                    OleDbDataReader dr = cmd1.ExecuteReader();

                    if (dr.HasRows)
                    {
                        dr.Read();
                        dictionary.Add(Convert.ToInt32(dr["ID"]), dr["Day_Time"].ToString());
                    }


                }

                if (e.Day.Date == Convert.ToDateTime(list_date[i]))
                {

                    if (dictionary.Count() > 0)
                    {
                        e.Cell.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        e.Cell.BackColor = System.Drawing.Color.Magenta;
                    }
                }


            }

            //Selectable Dates based on Doctor Schedule;
           // List<string> list_day = new List<string>();
            for (int k = 0; k < list1.Count(); k++)
            {
                string dayweek = "SELECT Day_Week FROM Schedule WHERE ID=" + list1[k] + ";";
                OleDbCommand cmd_day = new OleDbCommand(dayweek, con);
                OleDbDataReader dr_day = cmd_day.ExecuteReader();

                dr_day.Read();
                if (e.Day.Date < DateTime.Now)
                {

                    e.Day.IsSelectable = false;
                    e.Cell.ForeColor = System.Drawing.Color.LightGoldenrodYellow;


                }
                else
                {
                    if (dr_day["Day_Week"].ToString() == "Monday")
                    {
                        if (e.Day.Date.DayOfWeek == DayOfWeek.Monday)
                        {


                            e.Day.IsSelectable = true;
                            e.Cell.ForeColor = System.Drawing.Color.Green;


                        }
                    }

                    if (dr_day["Day_Week"].ToString() == "Tuesday")
                    {
                        if (e.Day.Date.DayOfWeek == DayOfWeek.Tuesday)
                        {


                            e.Day.IsSelectable = true;
                            e.Cell.ForeColor = System.Drawing.Color.Green;


                        }
                    }

                    if (dr_day["Day_Week"].ToString() == "Wednesday")
                    {
                        if (e.Day.Date.DayOfWeek == DayOfWeek.Wednesday)
                        {


                            e.Day.IsSelectable = true;
                            e.Cell.ForeColor = System.Drawing.Color.Green;


                        }
                    }

                    if (dr_day["Day_Week"].ToString() == "Thursday")
                    {
                        if (e.Day.Date.DayOfWeek == DayOfWeek.Thursday)
                        {


                            e.Day.IsSelectable = true;
                            e.Cell.ForeColor = System.Drawing.Color.Green;


                        }
                    }

                    if (dr_day["Day_Week"].ToString() == "Friday")
                    {
                        if (e.Day.Date.DayOfWeek == DayOfWeek.Friday)
                        {


                            e.Day.IsSelectable = true;
                            e.Cell.ForeColor = System.Drawing.Color.Green;


                        }
                    }
                }

               // list_day.Add(dr_day["Day_Week"].ToString());

            }
            /*
            if (e.Day.Date < DateTime.Now)
            {

                e.Day.IsSelectable = false;
                e.Cell.ForeColor = System.Drawing.Color.LightGoldenrodYellow;


            }
            else
            {

                
                if (list_day.Contains("Monday"))
                {

                    if (e.Day.Date.DayOfWeek == DayOfWeek.Monday)
                    {


                        e.Day.IsSelectable = true;
                        e.Cell.ForeColor = System.Drawing.Color.Green;


                    }

                }

                if (list_day.Contains("Tuesday"))
                {
                    if (e.Day.Date.DayOfWeek == DayOfWeek.Tuesday)
                    {

                        e.Day.IsSelectable = true;
                        e.Cell.ForeColor = System.Drawing.Color.Green;
                    }


                }

                if (list_day.Contains("Wednesday"))
                {
                    if (e.Day.Date.DayOfWeek == DayOfWeek.Wednesday)
                    {

                        e.Day.IsSelectable = true;
                        e.Cell.ForeColor = System.Drawing.Color.Green;

                    }

                }

                if (list_day.Contains("Thursday"))
                {
                    if (e.Day.Date.DayOfWeek == DayOfWeek.Thursday)
                    {

                        e.Day.IsSelectable = true;
                        e.Cell.ForeColor = System.Drawing.Color.Green;

                    }

                }

                if (list_day.Contains("Friday"))
                {
                    if (e.Day.Date.DayOfWeek == DayOfWeek.Friday)
                    {

                        e.Day.IsSelectable = true;
                        e.Cell.ForeColor = System.Drawing.Color.Green;
                    }

                }

                
            }
            */









            con.Close();
        }

        protected void Calendar1_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
        {
            Calendar1.DayRender += new DayRenderEventHandler(DayRenderCalendar);
        }
    }
}